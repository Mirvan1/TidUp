package com.example.myapplication.Models;


import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ProductResponse implements Serializable {

	@SerializedName("productQuantity")
	private Object productQuantity;

	@SerializedName("tf")
	private boolean tf;

	@SerializedName("folder")
	private Object folder;

	@SerializedName("productPhoto")
	private Object productPhoto;

	@SerializedName("productID")
	private Object productID;

	@SerializedName("productName")
	private Object productName;

	@SerializedName("productPrice")
	private Object productPrice;

	public void setProductQuantity(Object productQuantity){
		this.productQuantity = productQuantity;
	}

	public Object getProductQuantity(){
		return productQuantity;
	}

	public void setTf(boolean tf){
		this.tf = tf;
	}

	public boolean isTf(){
		return tf;
	}

	public void setFolder(Object folder){
		this.folder = folder;
	}

	public Object getFolder(){
		return folder;
	}

	public void setProductPhoto(Object productPhoto){
		this.productPhoto = productPhoto;
	}

	public Object getProductPhoto(){
		return productPhoto;
	}

	public void setProductID(Object productID){
		this.productID = productID;
	}

	public Object getProductID(){
		return productID;
	}

	public void setProductName(Object productName){
		this.productName = productName;
	}

	public Object getProductName(){
		return productName;
	}

	public void setProductPrice(Object productPrice){
		this.productPrice = productPrice;
	}

	public Object getProductPrice(){
		return productPrice;
	}

	@Override
 	public String toString(){
		return 
			"ProductResponse{" + 
			"productQuantity = '" + productQuantity + '\'' + 
			",tf = '" + tf + '\'' + 
			",folder = '" + folder + '\'' + 
			",productPhoto = '" + productPhoto + '\'' + 
			",productID = '" + productID + '\'' + 
			",productName = '" + productName + '\'' + 
			",productPrice = '" + productPrice + '\'' + 
			"}";
		}
}