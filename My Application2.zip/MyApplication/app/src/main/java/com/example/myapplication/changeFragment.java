package com.example.myapplication;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

public class changeFragment {
    private Context context;
    public changeFragment(Context context){
        this.context=context;

    }

//    public  void  change(Fragment fr) {
//        ((FragmentActivity) context).getSupportFragmentManager().beginTransaction()
//                .replace(R.id.viewPager,fr,"fragment")
//                .setTransitionStyle(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
//                .commit();
//    }

}
