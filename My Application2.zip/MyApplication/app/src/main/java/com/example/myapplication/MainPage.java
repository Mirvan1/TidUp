package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.myapplication.Utils.GetSharedPreferences;
import com.google.android.material.bottomnavigation.BottomNavigationMenu;
import com.google.android.material.bottomnavigation.BottomNavigationMenuView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainPage extends AppCompatActivity {
//    private SharedPreferences getSharedPreferences;
//    private GetSharedPreferences preferences;
    LinearLayout itemLinearLayout;
   BottomNavigationView bottomNavigationMenuView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_nav);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.item0:
                        itemLinearLayout=findViewById(R.id.listViewLayout);
                        FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                        ft1.add(R.id.listViewLayout, new fragmentMainPage());
                        ft1.commit();
                        Toast.makeText(MainPage.this, "main", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.item1:
                        Toast.makeText(MainPage.this, "qr", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.item2:
                        Toast.makeText(MainPage.this, "profile", Toast.LENGTH_SHORT).show();
                        break;
                }
                //return true;
            }
        });


        //\

//define();


    }
    public void define(){
        itemLinearLayout=findViewById(R.id.listViewLayout);
        FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
        ft1.add(R.id.listViewLayout, new fragmentMainPage());
        ft1.commit();
    }



//    public void define(){
//    preferences=new GetSharedPreferences(MainPage.this);
//    getSharedPreferences=preferences.getSession();
//    }
//    public void control(){
//        if(getSharedPreferences.getString("id",null)==null &&
//                getSharedPreferences.getString("email",null)==null
//                && getSharedPreferences.getString("username",null)==null){
////            Intent intent = new Intent(MainPage.this, ;
////            startActivity(intent);
////            finish();
//
//
//        }
//
//    }
}