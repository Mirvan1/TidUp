package com.example.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.myapplication.Models.Register;
import com.example.myapplication.Models.companyCreateJson;
import com.example.myapplication.RestApi.ManagerAll;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_APPEND;


public class createCompany extends Fragment {
    View view;
    Button createCompanyButtonUsingCode,generateCode;
    EditText companyNameText;
    TextView companyCodeText;
    String companyCode;

    public createCompany(){}
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_create_company, container, false);
        define();
        getNameOfCompany();
        return view;
    }
    public void define(){
        generateCode=view.findViewById(R.id.generateCode);
        createCompanyButtonUsingCode=view.findViewById(R.id.createCompanyButtonUsingCode);
        companyCodeText=view.findViewById(R.id.companyCodeText);
        companyNameText=view.findViewById(R.id.companyNameText);
    }

    public void getNameOfCompany() {
        generateCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=companyNameText.getText().toString();
                SharedPreferences sh = getContext().getSharedPreferences("company", Context.MODE_MULTI_PROCESS);
                String email = sh.getString("email", "");
                signCompany(name,email);
            }
        });
    }
    public void signCompany(String companyName,String email){
       // createCompany a=new createCompany();
  Call<companyCreateJson> req= ManagerAll.getInstance().create(companyName,email);
  req.enqueue(new Callback<companyCreateJson>() {
      @Override
      public void onResponse(Call<companyCreateJson> call, Response<companyCreateJson> response) {
          companyCode=response.body().getID();
          AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
          builder.setTitle("Your company ID");
          builder.setMessage("Company ID: "+companyCode);
          DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
              }
          };
          builder.setNegativeButton("No",dialogClickListener);
          AlertDialog dialog = builder.create();
          dialog.show();
      }
      @Override
      public void onFailure(Call<companyCreateJson> call, Throwable t) {
         // companyCode=response.body().getID();
          companyCode="Code can not generated";
      }
  });
    }
}