package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.myapplication.Models.ProductResponse;
import com.example.myapplication.RestApi.ManagerAll;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class fragmentMainPage extends Fragment {

    View view;
    //private LinearLayout itemLayout
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_main_page, container, false);
        getItemRequest("30");
    return view;
    }

    public void getItemRequest(String userID){
        Call<List<ProductResponse>>  itemReq= ManagerAll.getInstance().item(userID);
        itemReq.enqueue(new Callback<List<ProductResponse>>() {
            @Override
            public void onResponse(Call<List<ProductResponse>> call, Response<List<ProductResponse>> response) {
                Log.i("item list",response.body().toString());
                Toast.makeText(view.getContext(),response.body().toString(),Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<List<ProductResponse>> call, Throwable t) {
//                Log.i("item list",t.getCause().getMessage());
  //              Log.i("item list 2 ",t.getMessage());
//                Toast.makeText(view.getContext(),t.getCause().toString(),Toast.LENGTH_LONG).show();
                Log.i("item list","fail");
                Toast.makeText(view.getContext(),"ERRORERROR",Toast.LENGTH_LONG).show();
            }
        });


    }

}