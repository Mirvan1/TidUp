package com.example.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.Models.companyJoinJson;
import com.example.myapplication.RestApi.ManagerAll;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class joinCompany extends Fragment {
    View view;
    Button joinCompanyButtonUsingCode;
    EditText joinCompanyIDText;
    String companyNameReq;


    public joinCompany(){}
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view=inflater.inflate(R.layout.fragment_join_company, container, false);
        define();
        getIDofCompanyJoin();
        return view;
    }
    public void define(){
        joinCompanyIDText=view.findViewById(R.id.joinCompanyIDText);
        joinCompanyButtonUsingCode=view.findViewById(R.id.joinCompanyButtonUsingCode);
    }
    public  void getIDofCompanyJoin(){
        joinCompanyButtonUsingCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String joinID=joinCompanyIDText.getText().toString();
                SharedPreferences sh = getContext().getSharedPreferences("company", Context.MODE_MULTI_PROCESS);
                String email = sh.getString("emailJoin", "");
                joinResponse(email,joinID);
            }
        });


    }

    public void joinResponse(String email,String companyID){
        Call<companyJoinJson> request=ManagerAll.getInstance().join(email,companyID);
        request.enqueue(new Callback<companyJoinJson>() {
            @Override
            public void onResponse(Call<companyJoinJson> call, Response<companyJoinJson> response) {
                Object companyNameReq=response.body().getNameJoin();
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Your company");
                builder.setMessage("Is this your company? \n "+companyNameReq.toString());
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                };
                builder.setNegativeButton("No",dialogClickListener);
                AlertDialog dialog = builder.create();
                dialog.show();
            }

            @Override
            public void onFailure(Call<companyJoinJson> call, Throwable t) {
                companyNameReq="there was issue or there is no id like that";
                Toast.makeText(view.getContext(),companyNameReq,Toast.LENGTH_LONG).show();
            }
        });
    }
}