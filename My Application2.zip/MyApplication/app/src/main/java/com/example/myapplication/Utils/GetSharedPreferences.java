package com.example.myapplication.Utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class GetSharedPreferences {
    private  SharedPreferences sharedPreferences;
    private Activity activity;
    private Context context;
    public  GetSharedPreferences (Context context){
        this.context=context;
    }
    public SharedPreferences getSession(){
        sharedPreferences=activity.getSharedPreferences("session",0);
        return sharedPreferences;
    }
    public void  setSession(String id, String username,String email){
    sharedPreferences=context.getSharedPreferences("session",0);
    SharedPreferences.Editor editor=sharedPreferences.edit();
    editor.putString("id",id);
    editor.putString("username",username);
    editor.putString("email",email);
    editor.apply();


    }
}
