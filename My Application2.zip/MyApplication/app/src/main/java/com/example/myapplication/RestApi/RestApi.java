package com.example.myapplication.RestApi;

import com.example.myapplication.Models.ProductResponse;
import com.example.myapplication.Models.Register;
import com.example.myapplication.Models.companyCreateJson;
import com.example.myapplication.Models.companyJoinJson;
import com.example.myapplication.Models.loginJson;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface RestApi {
    //@Headers("Content-Type: application/json")
    @FormUrlEncoded
    @POST("/signup.php")
    Call<Register> registerUser(@Field("email") String email, @Field("username") String username, @Field("password") String password);


    @FormUrlEncoded
    @POST("/createCompany.php")
    Call<companyCreateJson> createCompanyUser(@Field("companyName") String companyName,@Field("email") String email);


    @FormUrlEncoded
    @POST("/joinCompany.php")
    Call<companyJoinJson> joinCompanyUser(@Field("email") String email, @Field("companyID") String companyID);


    @FormUrlEncoded
    @POST("/login_project.php")
    Call<loginJson> loginUser(@Field("email") String email, @Field("password") String password);


    @FormUrlEncoded
    @POST("/mainFragment.php")
    Call<List<ProductResponse>> itemList(@Field("userID") String userID);
}
