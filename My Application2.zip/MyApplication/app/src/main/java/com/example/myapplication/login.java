package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.Models.loginJson;
import com.example.myapplication.RestApi.ManagerAll;
import com.example.myapplication.Utils.GetSharedPreferences;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class login extends Fragment {
    View view;
    EditText loginEmail,loginPassword;
    Button loginButton;
    Context context;
    public login() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view= inflater.inflate(R.layout.fragment_login, container, false);
        define();
        toText();
        return view;
    }
    public void define(){
        loginPassword=view.findViewById(R.id.loginPassword);
        loginEmail=view.findViewById(R.id.loginEmail);
        loginButton=view.findViewById(R.id.loginButton);
    }
    public void toText(){

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=loginEmail.getText().toString();
                String password=loginPassword.getText().toString();
                loginRequest(email,password);
            }
        });


    }



    public void loginRequest(String email,String password){
        final Call<loginJson> req=ManagerAll.getInstance().login(email,password);
        req.enqueue(new Callback<loginJson>() {
            @Override
            public void onResponse(Call<loginJson> call, Response<loginJson> response) {
                Toast.makeText(getContext(),response.body().getText(),Toast.LENGTH_LONG).show();
                GetSharedPreferences getSharedPreferences=new GetSharedPreferences(getContext());
                getSharedPreferences.setSession(response.body().getİd(),response.body().getUsername(),response.body().getMail().toString());
                Intent intent = new Intent(getActivity(), MainPage.class);
                startActivity(intent);


            }

            @Override
            public void onFailure(Call<loginJson> call, Throwable t) {
                Toast.makeText(getContext(),t.getMessage(),Toast.LENGTH_LONG).show();
            }
        });

    }

}