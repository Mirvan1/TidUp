package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.Models.Register;
import com.example.myapplication.RestApi.ManagerAll;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SignUp extends Fragment {
        View view;
    private Button SignUpButton;
      EditText signEmail,signUsername,signPassword;
    ArrayList<String>  emailForCompany =new ArrayList<>();
    public SignUp() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view= inflater.inflate(R.layout.fragment_sign_up, container, false);
        define();
        signUser();
        return view;

    }


    public void define(){
        signEmail=view.findViewById(R.id.signEmail);
        signUsername=view.findViewById(R.id.signUsername);
        signPassword=view.findViewById(R.id.signPassword);
        SignUpButton=view.findViewById(R.id.SignUpButton);

    }

    public void signUser(){
        SignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=signEmail.getText().toString();
                String username=signUsername.getText().toString();
                String password=signPassword.getText().toString();
                SharedPreferences sharedPref =getContext().getSharedPreferences("company",Context.MODE_MULTI_PROCESS);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("email",email);
                editor.putString("emailJoin",email);
                editor.commit();

                sign(email,username,password);
                delete();
                Intent intent = new Intent(getActivity(), Company.class);
                startActivity(intent);
                }
            });
        }

     public void delete(){
        signEmail.setText("");
        signUsername.setText("");
        signPassword.setText("");
     }

     public void sign(String signEmail,String signUsername,String signPassword){
       Call<Register> request=ManagerAll.getInstance().register(signEmail,signUsername,signPassword);
         request.enqueue(new Callback<Register>() {
             @Override
             public void onResponse(Call<Register> call, Response<Register> response) {
                 Toast.makeText(view.getContext(), "sucess m", Toast.LENGTH_LONG).show();
//                    if(response.body().isTf()){
//
//                    }else{
//                        Toast.makeText(view.getContext(), "not sucess m", Toast.LENGTH_LONG).show();
//                    }

             }

             @Override
             public void onFailure(Call<Register> call, Throwable t) {
                 Toast.makeText(view.getContext(),  t.getMessage(), Toast.LENGTH_LONG).show();
                 //t.getCause().toString();
             }
         });
     }



}