package com.example.myapplication.Utils;

public class Dictionary {
    public static String problem1="Check Internet Connection";
    public static String log2="User Saved";
}
