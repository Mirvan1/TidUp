package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.app.Fragment;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Company extends AppCompatActivity {
    Button createCompanyButton,joinCompanyButton;
    FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
    FragmentTransaction ft2 = getSupportFragmentManager().beginTransaction();
   //Fragment fragment = getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT);
   int creatfragClosed=0;
    int joinFrag=0;
    public final String TAG_CREATE="create a company";
    public final String TAG_JOIN="join a company";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company);

        createCompanyButton=findViewById(R.id.createCompanyButton);
        joinCompanyButton=findViewById(R.id.joinCompanyButton);
        createCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                creatfragClosed+=1;
//                if(creatfragClosed%2==1){
//                    }
//                else{
//                    ft1.remove(new createCompany());
//                }
                ft1.add(R.id.frameLayout, new createCompany(),TAG_CREATE);
                ft1.commit();
            }
        });
        joinCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                 joinFrag+=1;
//                if(creatfragClosed%2==1) {
//
//                    ft2.add(R.id.frameLayoutJoin, new joinCompany(), TAG_JOIN);
//                    ft2.commit();
//                }
//                else{
//                    ft1.remove(new createCompany());
//                }
                ft2.add(R.id.frameLayoutJoin, new joinCompany(), TAG_JOIN);
                ft2.commit();

            }
        });
    }




}