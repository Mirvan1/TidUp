package com.example.myapplication.RestApi;

public class BaseURL {
    public static final String URL = "http://169.254.248.11/";
}
