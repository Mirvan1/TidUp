package com.example.myapplication.RestApi;


import com.example.myapplication.Models.ProductResponse;
import com.example.myapplication.Models.Register;
import com.example.myapplication.Models.companyCreateJson;
import com.example.myapplication.Models.companyJoinJson;
import com.example.myapplication.Models.loginJson;

import java.util.List;

import retrofit2.Call;

public class ManagerAll  extends BaseManager{

    private  static ManagerAll ourInstance = new ManagerAll();

    public  static synchronized ManagerAll getInstance()
    {
        return  ourInstance;
    }

    public Call<Register> register(String email , String username, String password)
    {
        Call<Register> x = getRestApi().registerUser(email,username,password);
        return  x ;
    }

    public Call<companyCreateJson> create(String companyName,String email )
    {
        Call<companyCreateJson> x = getRestApi().createCompanyUser(companyName,email);
        return  x ;
    }


    public Call<companyJoinJson> join(String email , String companyID)
    {
        Call<companyJoinJson> x = getRestApi().joinCompanyUser(email,companyID);
        return  x ;
    }


    public Call<loginJson> login(String email , String password)
    {
        Call<loginJson> x = getRestApi().loginUser(email,password);
        return  x ;
    }


    //

    public Call<List<ProductResponse>> item(String userID )
    {
        Call<List<ProductResponse>> x = getRestApi().itemList(userID);
        return  x ;
    }
}