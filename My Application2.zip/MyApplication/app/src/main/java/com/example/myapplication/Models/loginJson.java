package com.example.myapplication.Models;

import com.google.gson.Gson;

public class loginJson {
    /**
     * id : 60
     * username :
     * mail : null
     * password :
     * tf : false
     * text : You have to approve account using mail
     * companyID : null
     */

    private String id;
    private String username;
    private Object mail;
    private String password;
    private boolean tf;
    private String text;
    private Object companyID;

    public static loginJson objectFromData(String str) {

        return new Gson().fromJson(str, loginJson.class);
    }

    public String getİd() {
        return id;
    }

    public void setİd(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Object getMail() {
        return mail;
    }

    public void setMail(Object mail) {
        this.mail = mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isTf() {
        return tf;
    }

    public void setTf(boolean tf) {
        this.tf = tf;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Object getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Object companyID) {
        this.companyID = companyID;
    }
}
