package com.example.myapplication.Models;


import com.google.gson.Gson;

import java.util.ArrayList;

public class Register {

    /**
     * name : null
     * email : null
     */

    private Object name;
     Object email;


    public static Register objectFromData(String str) {

        return new Gson().fromJson(str, Register.class);
    }

    public Object getName() {
        return name;
    }

    public void setName(Object name) {
        this.name = name;
    }

    public Object getEmail() {
        return email;
    }

    public void setEmail(Object email) {
        this.email = email;
    }
}
